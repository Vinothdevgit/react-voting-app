import React, { useEffect, useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer } from 'recharts';

function ResultsPage({ token }) {
  const [results, setResults] = useState([]);

  useEffect(() => {
    fetch('http://localhost:8080/api/results', {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => setResults(data))
      .catch(err => console.error('Error fetching results:', err));
  }, [token]);

  if (!results.length) return <div style={styles.page}>Loading results...</div>;

  const winner = results.reduce((max, c) => (c.votes > max.votes ? c : max), results[0]);

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>🎉 Congratulations {winner.name} 🎉</h1>
      <h3 style={styles.subtitle}>Winner of this election!</h3>

      <div style={styles.chartBox}>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={results}>
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="votes" fill="#4f46e5" />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <ul style={styles.list}>
        {results.map(c => (
          <li key={c.id} style={styles.listItem}>
            {c.symbol || '🗳️'} {c.name} → {c.votes} votes
          </li>
        ))}
      </ul>
    </div>
  );
}

const styles = {
  page: {
    padding: '2rem',
    textAlign: 'center',
    background: 'linear-gradient(135deg, #f0f9ff, #ecfdf5)',
    minHeight: '100vh',
  },
  title: {
    fontSize: '2rem',
    fontWeight: 700,
    color: '#1f2937',
  },
  subtitle: {
    marginBottom: '1.5rem',
    fontSize: '1.2rem',
    color: '#6b7280',
  },
  chartBox: {
    background: '#fff',
    padding: '1rem',
    borderRadius: 12,
    boxShadow: '0 4px 14px rgba(0,0,0,0.1)',
    marginBottom: '2rem',
  },
  list: {
    listStyle: 'none',
    padding: 0,
    margin: '0 auto',
    maxWidth: 500,
    textAlign: 'left',
  },
  listItem: {
    fontSize: '1rem',
    padding: '0.5rem 0',
    borderBottom: '1px solid #e5e7eb',
  },
};

export default ResultsPage;
